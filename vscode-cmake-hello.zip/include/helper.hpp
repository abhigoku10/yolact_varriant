#ifndef HELPER_HPP_
#define HELPER_HPP_

#include <opencv2/opencv.hpp>
#include <Eigen/Eigen>
#include <unsupported/Eigen/NonLinearOptimization>
#include <NumCpp.hpp>
#include <iomanip>

struct LMFunctor
{
	// 'm' pairs of (x, f(x))
	Eigen::MatrixXf measuredValues;

	// Compute 'm' errors, one for each data point, for the given parameter values in 'x'
	int operator()(const Eigen::VectorXf &x, Eigen::VectorXf &fvec) const
	{
		// 'x' has dimensions n x 1
		// It contains the current estimates for the parameters.

		// 'fvec' has dimensions m x 1
		// It will contain the error for each data point.

		float aParam = x(0);
		float bParam = x(1);
		float cParam = x(2);

		for (int i = 0; i < values(); i++) {
			float xValue = measuredValues(i, 0);
			float yValue = measuredValues(i, 1);

			fvec(i) = yValue - (aParam * xValue * xValue + bParam * xValue + cParam);
		}
		return 0;
	}

	// Compute the jacobian of the errors
	int df(const Eigen::VectorXf &x, Eigen::MatrixXf &fjac) const
	{
		// 'x' has dimensions n x 1
		// It contains the current estimates for the parameters.

		// 'fjac' has dimensions m x n
		// It will contain the jacobian of the errors, calculated numerically in this case.

		float epsilon;
		epsilon = 1e-5f;

		for (int i = 0; i < x.size(); i++) {
			Eigen::VectorXf xPlus(x);
			xPlus(i) += epsilon;
			Eigen::VectorXf xMinus(x);
			xMinus(i) -= epsilon;

			Eigen::VectorXf fvecPlus(values());
			operator()(xPlus, fvecPlus);

			Eigen::VectorXf fvecMinus(values());
			operator()(xMinus, fvecMinus);

			Eigen::VectorXf fvecDiff(values());
			fvecDiff = (fvecPlus - fvecMinus) / (2.0f * epsilon);

			fjac.block(0, i, values(), 1) = fvecDiff;
		}

		return 0;
	}

	// Number of data points, i.e. values.
	int m;

	// Returns 'm', the number of values.
	int values() const { return m; }

	// The number of parameters, i.e. inputs.
	int n;

	// Returns 'n', the number of inputs.
	int inputs() const { return n; }

};

cv::Mat readImage(std::string path);
void saveImage(cv::Mat image, cv::String path);
void showImage(cv::Mat image);
void edgeParams(nc::NdArray<nc::uint8> image, unsigned rows, unsigned cols, nc::NdArray<int> &openEdges, nc::NdArray<int> &intersectEdges);
nc::NdArray<int> getComponents(nc::NdArray<nc::uint8> image, nc::NdArray<int> openEdges, nc::NdArray<int> intersectEdges, nc::NdArray<int> &indexes, unsigned &labelCount, cv::Mat &labels);
nc::NdArray<nc::uint8> L2PadImageByOne(nc::NdArray<nc::uint8> image);
nc::NdArray<nc::uint8> skeletonize(nc::NdArray<nc::uint8> img);
nc::NdArray<nc::uint8> mat2NC(cv::Mat image);

Eigen::VectorXf LMCurveFit(nc::NdArray<int> points, int direction);

// Code copied from https://github.com/VISWESWARAN1998/sklearn/blob/master/sklearn/mlr.h //
class LinearRegression
{
	private:
		// Independent variable X
		std::vector<std::vector<double>> X;

		std::vector<double> y;

		std::vector<double> bias;

		// unsigned short int verbose;
	// private:
	// 	void print(std::string message);
		
	public:
		// LinearRegression(std::string model_name);
		// LinearRegression(std::vector<std::vector<double>> X, std::vector<double> y, unsigned short int verbose) : X(X), y(y), verbose(verbose) {}
		LinearRegression(nc::NdArray<float> pX, nc::NdArray<float> py) 
		{
			for(int i=0; i<int(pX.numRows()); i++)
			{
				std::vector<double> temp;
				for(int j=0; j<int(pX.numCols()); j++)
					temp.push_back(double(pX(i, j)));
				X.push_back(temp);
			}
				
			for(int i=0; i<int(py.size()); i++)
				y.push_back(double(py[i]));
		}//: X(X), y(y), verbose(verbose) {}
		void fit();
		nc::NdArray<float> predict(nc::NdArray<float> test);
		// void save_model(std::string model_name);

		std::vector<double> get_bias();
};



#endif