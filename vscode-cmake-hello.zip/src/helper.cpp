#include "helper.hpp"
#include "matrix.h"

cv::Mat readImage(std::string path)
{
    cv::Mat img = cv::imread(path, cv::IMREAD_GRAYSCALE);
    return img;
}

void showImage(cv::Mat image)
{
    cv::String windowName = "The Guitar"; //Name of the window
    cv::namedWindow(windowName); // Create a window
    cv::imshow(windowName, image); // Show our image inside the created window.
    cv::waitKey(0); // Wait for any keystroke in the window
    cv::destroyWindow(windowName); //destroy the created window
}

void edgeParams(nc::NdArray<nc::uint8> image, unsigned rows, unsigned cols, nc::NdArray<int> &openEdges, nc::NdArray<int> &intersectEdges)
{
    
    auto a1 = nc::nonzero(image);
    int count = 0;
    for(unsigned i = 0; i < a1.first.numCols(); i++)
    {
        // Calculate surrounding sum to determine open pixel values
        if ((a1.first[i] > 1) && (a1.second[i] > 1) && (a1.first[i] < rows - 1) && (a1.second[i] < cols - 1))
        {
            int top = a1.first[i] - 1;
            int left = a1.second[i] - 1;
            int bottom = a1.first[i] + 2;
            int right = a1.second[i] + 2;
            auto sum = nc::sum(image({top, bottom}, {left, right}).astype<nc::int32>());
            if (sum[0] <= 511)
            {   
                count += 1;
                openEdges = nc::append(openEdges, {int(a1.first[i]), int(a1.second[i])}, nc::Axis::ROW);
            }
            else if (sum[0] >= 1020)
            {
                intersectEdges = nc::append(intersectEdges, {int(a1.first[i]), int(a1.second[i])}, nc::Axis::ROW);

            }
        }
    }
}

nc::NdArray<int> getComponents(nc::NdArray<nc::uint8> image, nc::NdArray<int> openEdges, nc::NdArray<int> intersectEdges, nc::NdArray<int> &indexes, unsigned &labelCount, cv::Mat &labels)
{
    cv::Mat stats, centroids, nz;    
    
    for (unsigned i = 1; i < intersectEdges.numRows(); i += 2)
        image(intersectEdges(i,0), intersectEdges(i,1)) = nc::uint8{0};
    cv::Mat cvArray = cv::Mat(image.numRows(), image.numCols(), CV_8U, image.data());
    labelCount = cv::connectedComponentsWithStats(cvArray, labels, stats, centroids);
    nc::NdArray<int> componentPoints = nc::NdArray<int>({0,0});
    cv::findNonZero(labels, nz);
    int currentComponent = -1;
    for(unsigned j=1; j < openEdges.numRows(); j++) // 
    {
        currentComponent = labels.at<int>(openEdges(j, 0), openEdges(j, 1));
        for(unsigned i=0; i< nz.total(); i++)
        {
            if(labels.at<int>(nz.at<cv::Point>(i).y, nz.at<cv::Point>(i).x) == currentComponent)
                componentPoints = nc::append(componentPoints,  {int(nz.at<cv::Point>(i).y), int(nz.at<cv::Point>(i).x)}, nc::Axis::ROW);
        }            
        indexes = nc::append(indexes, {int(componentPoints.numRows())});
    }                
    return componentPoints;    
}

nc::NdArray<nc::uint8> L2PadImageByOne(nc::NdArray<nc::uint8> image)
{
    auto padImage = nc::zeros<nc::uint8>(image.numRows() + 2, image.numCols() + 2);
    auto nz = nc::nonzero(image);
    for(unsigned i = 0; i < nz.first.numCols(); i++)
        padImage(nz.first[i] + 1, nz.second[i] + 1) = image(nz.first[i], nz.second[i]);
    return padImage;
}

nc::NdArray<nc::uint8> skeletonize(nc::NdArray<nc::uint8> img)
{
    int arr[] = {0, 0, 0, 1, 0, 0, 1, 3, 0, 0, 3, 1, 1, 0, 1, 3, 0, 0, 0, 0, 0, 0,
       0, 0, 2, 0, 2, 0, 3, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 2, 2, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0,
       0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 3, 0, 2, 0, 0, 0, 3, 1,
       0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 3, 0, 0,
       1, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 2, 3, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3,
       0, 1, 0, 0, 0, 0, 2, 2, 0, 0, 2, 0, 0, 0};
    img = img / nc::uint8{255};
    auto padImage = L2PadImageByOne(img);
    auto skeletonImage = padImage.copy();
    int pixRemoved = 1;
    int count = 0;
    while (pixRemoved == 1)
    {
        pixRemoved = 0;
        for(int k=0; k< 2; k++)
        {
            for(unsigned i = 1; i < (padImage.numRows() - 1); i++)
                for(unsigned j = 1; j < (padImage.numCols() - 1); j++)
                {
                    if(skeletonImage(i, j) != 0)
                    {
                        auto neighbors = skeletonImage(i - 1, j - 1) + 2*skeletonImage(i - 1, j) +\
                            4*skeletonImage(i - 1, j + 1) + 8*skeletonImage(i, j + 1) +\
                            16*skeletonImage(i + 1, j + 1) + 32*skeletonImage(i + 1, j) +\
                            64*skeletonImage(i + 1, j - 1) + 128*skeletonImage(i, j - 1);
                        if(((arr[neighbors] == 1) && (k == 0)) ||\
                            ((arr[neighbors] == 2) && (k != 0)) ||\
                            (arr[neighbors] == 3))
                        {
                            padImage(i, j) = 0;
                            pixRemoved = 1;
                        }            
                    }
                }
            skeletonImage = padImage;
        }
    }
    skeletonImage = skeletonImage * nc::uint8{255};
    return skeletonImage({1,int(padImage.numRows() - 1)}, {1,int(padImage.numCols() - 1)});
}

nc::NdArray<nc::uint8> mat2NC(cv::Mat image)
{
    return nc::NdArray<nc::uint8>(image.data, image.rows, image.cols); 
}

Eigen::VectorXf LMCurveFit(nc::NdArray<int> points, int direction)
{
    int m = int(points.numRows());
    Eigen::MatrixXf measuredValues(m, 2);
    if(direction%2 == 0)
        for (int i = 0; i < m; i++) {
            measuredValues(i, 0) = float(points(i, 1));
            measuredValues(i, 1) = float(points(i, 0));
        }
    else
        for (int i = 0; i < m; i++) {
            measuredValues(i, 0) = float(points(i, 0));
            measuredValues(i, 1) = float(points(i, 1));
        }

	int n = 3;

	Eigen::VectorXf x(n);
	x(0) = 0.0;             // initial value for 'a'
	x(1) = 0.0;             // initial value for 'b'
	x(2) = 0.0;             // initial value for 'c'

	LMFunctor functor;
	functor.measuredValues = measuredValues;
	functor.m = m;
	functor.n = n;

	Eigen::LevenbergMarquardt<LMFunctor, float> lm(functor);
	int status = lm.minimize(x);
	return x;

}

// void LinearRegression::print(std::string message)
// {
// 	if (verbose) std::cout << message << "\n";
// }

// LinearRegression::LinearRegression(std::string model_name)
// {
// 	std::ifstream file;
// 	file.open(model_name);
// 	if (!file.is_open()) throw "Model cannot be loaded because it cannot be opened!";
// 	json j;
// 	file >> j;
// 	file.close();
// 	std::vector<double> b = j["bias"];
// 	bias = b;
// }

void LinearRegression::fit()
{
	// Adding bias to X
	for (unsigned long int i = 0; i < X.size(); i++)
	{
		std::vector<double> row;
		row.push_back(1);
		for (double j : X[i])
		{
			row.push_back(j);
		}
		X[i] = row;
	}

	// X'
	std::vector<std::vector<double>> X_transpose;

	// X'X
	std::vector<std::vector<double>> X_transpose_X;

	matrix<double> mat;

	// print("Finding the transpose");
	X_transpose = mat.transpose(X);
	// print("Finding X'X");
	X_transpose_X = mat.mul(X_transpose, X);
	// print("Found!");
	std::vector<double> rows(X_transpose_X[0].size(), 1);
	// (X'X)-1
	std::vector<std::vector<double>> inverse_of_X_transpose_X(X_transpose_X.size(), rows);
	// find the inverse
	// print("Finding (X'X)^-1");
	// Print the matrix shapes for debug messages
	std::stringstream s1;
	// s1 << "Shape of X transpose X: " << X_transpose_X.size() << "," << X_transpose_X[0].size();
	// print(s1.str());
	// std::stringstream s2;
	// s2 << "Shape of inverse of X transpose X: " << inverse_of_X_transpose_X.size() << "," << inverse_of_X_transpose_X[0].size();
	// print(s2.str());
	mat.inverse(X_transpose_X, inverse_of_X_transpose_X);
	// Reshape y
	// print("Reshaping y");
	std::vector<std::vector<double>> y_reshaped;
	for (double i : y)
	{
		std::vector<double> row;
		row.push_back(i);
		y_reshaped.push_back(row);
	}
	std::vector<std::vector<double>> X_transpose_y = mat.mul(X_transpose, y_reshaped);
	std::vector<std::vector<double>> b = mat.mul(inverse_of_X_transpose_X, X_transpose_y);
	for (std::vector<double> i : b)
	{
		bias.push_back(i[0]);
	}
	// print("Found");
}

// double LinearRegression::predict(std::vector<double> test)
nc::NdArray<float> LinearRegression::predict(nc::NdArray<float> test)
{
	auto yPred = nc::zeros<float>(int(test.numRows()), 1);
	for (int i = 0; i < int(test.numRows()); i++)
	{
        double prediction = 0.0;
        prediction += bias[0];
		for(int j = 0; j < int(test.numCols()); j++)
        {
            double value = bias[j + 1] * test(i, j);
            prediction += value;
        }
        yPred(0, i) = float(prediction);
	}
	return yPred;
}

// void LinearRegression::save_model(std::string model_name)
// {
// 	json j;
// 	j["bias"] = bias;
// 	std::ofstream file;
// 	file.open(model_name);
// 	if (file.is_open())
// 	{
// 		file << std::setw(4) << j << std::endl;
// 		file.close();
// 	}
// 	else
// 	{
// 		throw "File cannot be opened for saving the model. May be the file is opened in some other place or you might not have proper permissions.";
// 	}
// }

std::vector<double> LinearRegression::get_bias()
{
	return bias;
}