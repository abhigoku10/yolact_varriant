#include "helper.hpp"

using namespace std;

float pPartCube(float x)
{
    return float(pow(x, 3));
}

nc::NdArray<float> naturalInHouse(nc::NdArray<float> pts, int fittingMethod, int overSamplingFactor)
{
    // pts.print();
    auto distanceAcc = nc::cumsum(nc::sqrt(nc::sum(nc::square(nc::diff(pts, nc::Axis::ROW)), nc::Axis::COL)));
    auto distance = nc::zeros<float>(1, int(distanceAcc.size()) + 1);
    for(int i=0; i<int(distanceAcc.size()); i++)
        distance[i + 1] = distanceAcc[i] / distanceAcc[-1];
    auto alpha = nc::linspace(0.0, 1.0, int(pts.numRows()) * overSamplingFactor).astype<float>();
    if((fittingMethod == 3) && (int(pts.numRows()) > 3))
    {
        // auto minVal = nc::min(pts({0, int(pts.numRows())}, {1,2}))[0];
        // auto maxVal = nc::max(pts({0, int(pts.numRows())}, {1,2}))[0];
        auto minVal = nc::min(distance)[0];
        auto maxVal = nc::max(distance)[0];
        int nKnots = max(2, int(pts.numRows() / 3));
        auto knot = nc::linspace(minVal, maxVal, nKnots+2);
        auto knots = knot({0,1}, {1,-1});
        auto trainDist = nc::zeros<float>(int(pts.numRows()), int(knots.size()) - 1);
        float numerator1, denominator1, numerator2, denominator2;
        for(int i=0; i<int(knots.size()) -2; i++)
        {
            for(int j=0; j<int(pts.numRows()); j++)
            {
                numerator1 = pPartCube(max(float(0), distance(0, j) - knots(0, i))) - pPartCube(max(float(0), distance(0, j) - knots(0, int(knots.size()) - 1)));
                denominator1 = knots(0, int(knots.size()) - 1) - knots(0, i);

                numerator2 = pPartCube(max(float(0), distance(0, j) - knots(0, int(knots.size())-2))) - pPartCube(max(float(0), distance(0, j) - knots(0, int(knots.size()) - 1)));
                denominator2 = knots(0, int(knots.size()) - 1) - knots(0, int(knots.size())-2);

                trainDist(j, i+1) = (numerator1/denominator1) - (numerator2/denominator2);
            }
        }
        for(int j=0; j<int(pts.numRows()); j++)
        {
            trainDist(j, 0) = distance(0, j);
        }
        // trainDist.print();
        // pts(pts.rSlice(), 0).print();
        // LinearRegression mlrY(trainDist, pts(pts.rSlice(), 0));
        // mlrY.fit();
        // LinearRegression mlrX(trainDist, pts(pts.rSlice(), 1));
        // mlrX.fit();
        auto ps = nc::linalg::lstsq(trainDist, pts(pts.rSlice(), 0));
        ps.print();
        // auto predDist = nc::zeros<float>(int(alpha.size()), int(knots.size()) - 1);
        // for(int i=0; i<int(knots.size()) -2; i++)
        // {
        //     for(int j=0; j<int(alpha.size()); j++)
        //     {
        //         numerator1 = pPartCube(max(float(0), alpha[j] - knots(0, i))) - pPartCube(max(float(0), alpha[j] - knots(0, int(knots.size()) - 1)));
        //         denominator1 = knots(0, int(knots.size()) - 1) - knots(0, i);

        //         numerator2 = pPartCube(max(float(0), alpha[j] - knots(0, int(knots.size())-2))) - pPartCube(max(float(0), alpha[j] - knots(0, int(knots.size()) - 1)));
        //         denominator2 = knots(0, int(knots.size()) - 1) - knots(0, int(knots.size())-2);

        //         predDist(j, i+1) = (numerator1/denominator1) - (numerator2/denominator2);
        //     }
        // }
        // for(int j=0; j<int(pts.numRows()); j++)
        // {
        //     predDist(j, 0) = distance(0, j);
        // }
        // auto yPred = mlrY.predict(predDist);        
        // auto xPred = mlrX.predict(predDist);    
        // pts.print();
        // yPred.print();
        // xPred.print();    

    }
    
    // pts(pts.rSlice(), 0).print();
    // nc::cumsum(nc::sum(nc::square(nc::diff(pts, nc::Axis::ROW)), nc::Axis::COL));
    // LinearRegression mlr(finalVal, pts(pts.rSlice(), 1));
    // mlr.fit();
    // auto xPred = mlr.predict(finalVal);
    return pts;
}

int main()
{
    auto a = nc::NdArray<float>{{ 28, 121},      { 29, 111},       { 29, 112},       { 29, 113},       { 29, 114},       { 29, 115},       { 29, 116},       { 29, 117},       { 29, 118},       { 29, 119},       { 29, 120},       { 30, 105},       { 30, 106},       { 30, 107},
 { 30, 108},      { 30, 109},     { 30, 110},        { 31, 103},       { 31, 104},       { 32, 100},       { 32, 101},       { 32, 102},       { 33,  99},       { 34,  98},       { 35,  98},       { 36,  98},       { 37,  98},       { 38,  98},
 { 39,  98},      { 40,  98},      { 41,  98},         { 42,  98},       { 43,  98},       { 44,  98},       { 45,  98},       { 46,  98},       { 47,  98},       { 48,  99},       { 49,  99},       { 50, 100},       { 51, 100},       { 52, 100},
 { 53, 101},      { 54, 102},     { 55, 102},        { 56, 103},       { 57, 103},       { 58, 104},       { 59, 104},       { 60, 105},       { 61, 105},       { 62, 106},       { 63, 106},       { 64, 106},       { 65, 106},       { 66, 107},
 { 67, 107},       { 68, 107},       { 69, 107},       { 70, 108},       { 71, 108},       { 72, 109},       { 73, 109},       { 74, 109},       { 75, 110},       { 76, 110},       { 77, 111},       { 78, 111},       { 79, 111},       { 80, 111},
 { 81, 111},       { 82, 111},       { 83, 112},       { 84, 112},       { 85, 113},       { 86, 113},       { 87, 113},       { 88, 113},       { 89, 113},       { 90, 113},       { 91, 113},       { 92, 113},       { 93, 114},       { 94, 114},
 { 95, 114},       { 96, 115},       { 97, 115},       { 98, 115},       { 99, 116},       {100, 116},       {101, 116},       {102, 116},       {103, 117},       {104, 117},       {105, 118},       {106, 118},       {107, 118},       {108, 118},
 {109, 118},       {110, 118},       {111, 118},       {112, 118},       {113, 118},       {114, 118},       {115, 118},       {116, 118},       {117, 118},       {118, 118},       {119, 118},       {120, 118},       {121, 118},       {122, 118},
 {123, 118},       {124, 118},       {125, 118},       {126, 117},       {127, 116},       {128, 115},       {129, 114},       {130, 113},       {131, 113},       {132, 112},       {133, 111},       {134, 110},       {135, 109},       {136, 106},
 {136, 107},       {136, 108},       {137, 105},       {138,  94},       {138,  95},       {138,  96},       {138,  97},       {138,  98},       {138,  99},       {138, 100},       {138, 101},       {138, 102},       {138, 103},       {138, 104},
 {139,  86},       {139,  87},       {139,  88},       {139,  89},       {139,  90},       {139,  91},       {139,  92},       {139,  93},       {140,  84},       {140,  85},       {141,  71},       {141,  72},       {141,  73},       {141,  74},       {141,  75},
  {141,  76},       {141,  77},       {141,  78},       {141,  79},       {141,  80},       {141,  81},       {141,  82},       {141,  83}};
    auto p = naturalInHouse(a, 3, 4);
    // auto a = nc::NdArray<float>{{0, 0}, {2,4}, {4, 8}, {6, 12}, {8, 16}, {10, 20}};
    // auto val = nc::cumsum(nc::sqrt(nc::sum(nc::square(nc::diff(a, nc::Axis::ROW)), nc::Axis::COL)));
    // auto distance = nc::zeros<float>(1, int(val.size()) + 1);
    // for(int i=0; i<int(val.size()); i++)
    //     distance[i + 1] = val[i] / val[-1];
    // distance.print();
    // cv::Mat img = readImage("E:\\Codes\\C++\\opencv\\curves.png");
    // auto ncImg = mat2NC(img);
    // auto skelImg = skeletonize(ncImg);
    // auto sMg = ncImg.copy();
    // sMg = nc::uint8{0};
    // nc::NdArray<int> totalOpenEdges = {{0,0}};
    // nc::NdArray<int> junctions = {{0,0}};
    // nc::NdArray<int> indexes = {{1}};
    // unsigned labelCount;
    // cv::Mat labels;
    // edgeParams(skelImg, skelImg.numRows(), skelImg.numCols(), totalOpenEdges, junctions);
    // auto componentPoints = getComponents(skelImg, totalOpenEdges, junctions, indexes, labelCount, labels);
    // if(totalOpenEdges.numRows() > 1)
    //     for(unsigned openEdge = 1; openEdge < totalOpenEdges.numRows(); openEdge++)
    //     {
    //         auto currentComponent = labels.at<int>(totalOpenEdges(openEdge, 0), totalOpenEdges(openEdge, 1));
    //         auto currentComponentPoints = componentPoints({indexes[openEdge - 1], indexes[openEdge]}, {0, 2});
    //         // currentComponentPoints = currentComponentPoints.astype<>();
    //         // currentComponentPoints.print();
    //         auto xPred = naturalInHouse(currentComponentPoints.astype<float>(), 3, 4);
    //         // xPred.print();
    //         // for(int j=0; j<int(currentComponentPoints.numRows()); j++)
    //         // {
    //         //     sMg(currentComponentPoints(j, 0), int(xPred(0, j))) = nc::uint8{255};
    //         // }
    //     }
    // cv::Mat cvArray = cv::Mat(sMg.numRows(), sMg.numCols(), CV_8U, sMg.data());
    // showImage(cvArray);
    
    // nc::NdArray<float> yx = {{0, 0}, {1, 1}, {2, 2},
    //                        {3, 3}, {4, 4}, {5, 5},
    //                        {6, 6}, {7, 7}, {8, 8},
    //                        {9, 9}};
    // yx.astype<float>();
    

    return 0;
}
